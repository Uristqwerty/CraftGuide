Note: Do not alter any of the files in this directory, they are overwritten when CraftGuide loads.

If you want to replace them entirely, copy them to a new theme, and make your edits there. Anything changed in that theme will overwrite the defaults when that theme loads.