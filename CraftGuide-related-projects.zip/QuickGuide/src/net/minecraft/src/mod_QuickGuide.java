package net.minecraft.src;


import org.lwjgl.input.Keyboard;

import uristqwerty.CraftGuide.GuiCraftGuide;

public class mod_QuickGuide extends BaseMod
{
	private KeyBinding key = new KeyBinding("Open CraftGuide", Keyboard.KEY_G);
	private GuiCraftGuide gui;
	
	public mod_QuickGuide()
	{
		ModLoader.registerKey(this, key, false);
	}

	@Override
	public void keyboardEvent(KeyBinding keybinding)
	{
		if(keybinding == key && ModLoader.getMinecraftInstance().currentScreen == null)
		{
			ModLoader.getMinecraftInstance().displayGuiScreen(GuiCraftGuide.getInstance());
		}
	}

	@Override
	public String getVersion()
	{
		return "1.2.3";
	}

	@Override
	public void load()
	{
	}
}
