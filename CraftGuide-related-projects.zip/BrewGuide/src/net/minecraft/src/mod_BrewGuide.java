package net.minecraft.src;


public class mod_BrewGuide extends BaseMod
{
	public mod_BrewGuide()
	{
		new BrewGuideRecipes();
	}
	
	@Override
	public String getVersion()
	{
		return "1.0";
	}

	@Override
	public void load()
	{
	}
}
