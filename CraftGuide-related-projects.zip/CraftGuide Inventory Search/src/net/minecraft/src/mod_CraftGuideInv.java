package net.minecraft.src;

import java.lang.reflect.Field;


import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import uristqwerty.CraftGuide.GuiCraftGuide;

public class mod_CraftGuideInv extends BaseMod
{
	private KeyBinding key = new KeyBinding("View item in CraftGuide", Keyboard.KEY_G);
	
	@Override
	public String getVersion()
	{
		return "1.0";
	}

	@Override
	public void load()
	{
		ModLoader.registerKey(this, key, false);
	}

	@Override
	public void keyboardEvent(KeyBinding keybinding)
	{
		if(keybinding == key)
		{
			GuiScreen screen = ModLoader.getMinecraftInstance().currentScreen;
			
			if(screen == null)
			{
				ModLoader.getMinecraftInstance().displayGuiScreen(GuiCraftGuide.getInstance());
			}
			else if(screen instanceof GuiContainer)
			{
				try
				{
					int x = Mouse.getX() * screen.width / screen.mc.displayWidth;
					int y = screen.height - (Mouse.getY() * screen.height / screen.mc.displayHeight) - 1;
					int left = (Integer)getPrivateValue(GuiContainer.class, screen, "e");
					int top = (Integer)getPrivateValue(GuiContainer.class, screen, "f");
					openRecipe((GuiContainer)screen, x - left, y - top);
				}
				catch(IllegalArgumentException e)
				{
					e.printStackTrace();
				}
				catch(SecurityException e)
				{
					e.printStackTrace();
				}
				catch(NoSuchFieldException e)
				{
					e.printStackTrace();
				}
				catch(IllegalAccessException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	private Object getPrivateValue(Class<GuiContainer> classToAccess, Object object, String string) throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
	{
        Field f = classToAccess.getDeclaredField(string);
        f.setAccessible(true);
        return f.get(object);
	}

	private void openRecipe(GuiContainer screen, int x, int y)
	{
		Container container = screen.inventorySlots;
		
		for(int i = 0; i < container.inventorySlots.size(); i++)
		{
			Slot slot = (Slot)container.inventorySlots.get(i);
	        if(x > slot.xDisplayPosition - 2 && x < slot.xDisplayPosition + 17 && y > slot.yDisplayPosition - 2 && y < slot.yDisplayPosition + 17)
	        {
	        	ItemStack item = slot.getStack();
	        	
	        	if(item != null)
	        	{
	        		GuiCraftGuide.getInstance().setFilterItem(item);
	    			ModLoader.getMinecraftInstance().displayGuiScreen(GuiCraftGuide.getInstance());
	        	}
	        	
	        	break;
	        }
		}
	}
}
