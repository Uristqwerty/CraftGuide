package buildcraft.core;

import net.minecraft.src.ItemStack;

public class AssemblyRecipe
{
	public final ItemStack[] input;
	public final ItemStack output;
	public final float energy;
	
	public AssemblyRecipe()
	{
		input = null;
		output = null;
		energy = 0;
	}
}
