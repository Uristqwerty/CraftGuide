import eloraam.base.BlockAppliance;


public class RedPowerBase
{
	public static BlockAppliance blockAppliance;
}
