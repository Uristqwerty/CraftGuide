package eloraam.base;

import net.minecraft.src.Material;
import eloraam.core.BlockExtended;

public class BlockAppliance extends BlockExtended
{

	protected BlockAppliance(int i, Material material)
	{
		super(i, material);
		// TODO Auto-generated constructor stub
	}

}
