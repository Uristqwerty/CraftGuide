package eloraam.core;

import net.minecraft.src.BlockContainer;
import net.minecraft.src.Material;
import net.minecraft.src.TileEntity;

public class BlockExtended extends BlockContainer
{

	protected BlockExtended(int i, Material material)
	{
		super(i, material);
		// TODO Auto-generated constructor stub
	}

	@Override
	public TileEntity getBlockEntity()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
