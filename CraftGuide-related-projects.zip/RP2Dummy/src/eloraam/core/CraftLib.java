package eloraam.core;

import java.util.ArrayList;
import java.util.List;

public class CraftLib
{
	static List alloyRecipes = new ArrayList();
}
