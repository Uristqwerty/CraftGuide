package net.minecraft.src;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.client.Minecraft;
import net.minecraft.src.BaseMod;


public class mod_CraftHide extends BaseMod
{
	Set<Integer> excludedIDs = new HashSet<Integer>();
	
	@Override
	public String getVersion()
	{
		return "1.0.0";
	}

	@Override
	public void load()
	{
		new CraftHideFilter(this);
		
		loadList();
	}

	private void loadList()
	{
		File configDir = new File(Minecraft.getMinecraftDir(), "/config/");
		File configFile = new File(configDir, "CraftHide excluded items.txt");
		

		if(configFile.exists() && configFile.canRead())
		{
			try {
				loadList(new BufferedReader(new FileReader(configFile)));
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		else if(!configFile.exists())
		{
			try {
				configFile.createNewFile();
			}
			catch(IOException e) {
				e.printStackTrace();
			}
				
			if(configFile.exists() && configFile.canWrite())
			{
				try {
					FileWriter stream = new FileWriter(configFile);
					stream.write("# List the IDs that you don't want to show up in CraftGuide here.\n");
					stream.write("# Put one on each line, digits only\n");
					stream.flush();
					stream.close();
				}
				catch(FileNotFoundException e) {
					e.printStackTrace();
				}
				catch(IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void loadList(BufferedReader reader) throws IOException
	{
		String line;
		while((line = reader.readLine()) != null)
		{
			if(!line.startsWith("#"))
			{
				addLine(line);
			}
		}
	}

	private void addLine(String line)
	{
		try
		{
			int id = Integer.valueOf(line);
			excludedIDs.add(id);
		}
		catch(NumberFormatException e){}
	}

	public Set<Integer> excluded()
	{
		return excludedIDs;
	}
}
