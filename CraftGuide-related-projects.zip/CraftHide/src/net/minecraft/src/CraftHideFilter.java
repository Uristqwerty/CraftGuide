package net.minecraft.src;

import java.util.LinkedList;
import java.util.List;

import net.minecraft.src.CraftGuide.API.CraftGuideAPIObject;
import net.minecraft.src.CraftGuide.API.ICraftGuideRecipe;
import net.minecraft.src.CraftGuide.API.IRecipeFilter;

public class CraftHideFilter extends CraftGuideAPIObject implements	IRecipeFilter
{
	private mod_CraftHide craftHide;
	
	public CraftHideFilter(mod_CraftHide mod)
	{
		super();
		
		craftHide = mod;
	}

	@Override
	public List<ICraftGuideRecipe> removeRecipes(List<ICraftGuideRecipe> allRecipes)
	{
		List<ICraftGuideRecipe> filteredList = new LinkedList<ICraftGuideRecipe>();
		
		recipeLoop:
		for(ICraftGuideRecipe recipe: allRecipes)
		{
			for(ItemStack stack: recipe.getItems())
			{
				if(stack != null && craftHide.excluded().contains(stack.itemID))
				{
					continue recipeLoop;
				}
			}
			
			filteredList.add(recipe);
		}
		
		return filteredList;
	}
}
